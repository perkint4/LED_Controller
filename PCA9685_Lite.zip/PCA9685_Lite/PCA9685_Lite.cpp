// <copyright file="PCA9685_Lite.cpp" company="LEDbloke">
// Copyright (c) 2015, NEO12 Limited. All rights reserved.
// LEDbloke is a trading name of NEO12 Limited.
// http://www.ledbloke.co.uk
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 1. Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// 3. Neither the name of the copyright holders nor the
// names of its contributors may be used to endorse or promote products
// derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// </copyright>
// <author>Ibraheem Hlaiyil</author>
// <email>info@ledbloke.co.uk</email>
// <date>2015-02-09</date>
// <summary>Minimal implementation for PCA9685. Assumes I2C address of 0x40 (A0-A5 connected to GND). PWM frequency is default 200Hz.</summary>

#include <PCA9685_Lite.h>
#include <Wire.h>

void PCA9685_Lite::begin(void) {
	
	// Start I2C (@ 100kHz for Arduino)
	Wire.begin();
	//TWBR = 12; // uncomment to run I2C bus at 400kHz but at the expense of more memory!
	
	// Software Reset
	Wire.beginTransmission(PCA9685_GENCALL_I2CADDR);
	Wire.write(PCA9685_SWRST);
	Wire.endTransmission();
	delay(1000);

	// Turn AI on
	Wire.beginTransmission(PCA9685_DEFAULT_I2CADDR);
	Wire.write(PCA9685_MODE1);
	Wire.write(PCA9685_DEFAULT_MODE1 | PCA9685_MODE1_AI);
	Wire.endTransmission();
}

// Set PWM supporting fully on and fully off, at the expense of more memory!
void PCA9685_Lite::setPWM(uint8_t channel, uint16_t dutyCycle) {

	Wire.beginTransmission(PCA9685_DEFAULT_I2CADDR);
	Wire.write(PCA9685_LED0_ON_L + (4 * channel));

	Wire.write(0);

	if (dutyCycle == 0) {
		Wire.write(0);
		Wire.write(0);
		Wire.write(1 << 4);
	}
	else if (dutyCycle >= 4096) {
		Wire.write(1 << 4);
		Wire.write(0);
		Wire.write(0);
	}
	else {
		Wire.write(0);
		Wire.write(dutyCycle);
		Wire.write(dutyCycle >> 8);
	}

	Wire.endTransmission();
}

// Set PWM ignoring fully on and fully off
void PCA9685_Lite::setPWMLite(uint8_t channel, uint16_t dutyCycle) {

	Wire.beginTransmission(PCA9685_DEFAULT_I2CADDR);
	Wire.write(PCA9685_LED0_ON_L + (4 * channel));
	Wire.write(0);
	Wire.write(0);
	Wire.write(dutyCycle);
	Wire.write(dutyCycle>>8);
	Wire.endTransmission();
}




